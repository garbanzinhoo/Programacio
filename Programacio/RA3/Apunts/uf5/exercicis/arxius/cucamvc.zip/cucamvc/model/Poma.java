package uf5.exercicis.cucamvc.model;

import java.awt.*;

/**
 * Classe per guardar les dades de la poma (posició)
 */
public class Poma {
    private final Point p;

    /**
     * Constructor.
     * @param fila Fila on es posarà la poma
     * @param columna Columna on es posarà la poma
     */
    public Poma(int fila, int columna) {
        p = new Point(columna, fila);
    }

    public int getFila() {
        return p.y;
    }

    public int getColumna() {
        return p.x;
    }
}
