package uf5.exercicis.cucamvc.model;

import java.awt.Point;

/**
 * Classe per gestionar el tauler
 */
public class Tauler {

    // Nombre de files i columnes
    private final int files;
    private final int columnes;

    // Tauler: # (vores), P (poma), 0 (cuc)
    private final char[][] tauler;

    /**
     * Constructor del tauler.
     * @param f Nombre de files
     * @param c Nombre de columnes
     */
    public Tauler(int f, int c) {
        files = f;
        columnes = c;
        tauler = new char[files][columnes];
    }

    /**
     * Inicialitzar el tauler.
     */
    public void inicialitzar() {
        // Buidar tauler marcant els límits amb #
        for (int i = 0; i < files; ++i) {
            for (int j = 0; j < columnes; ++j) {
                if (i == 0 || i == files - 1 || j == 0 || j == columnes - 1) {
                    tauler[i][j] = '#';
                } else {
                    tauler[i][j] = ' ';
                }
            }
        }
    }

    public void set(Point p, char c) {
        set(p.y, p.x, c);
    }

    public void set(int f, int c, char ch) {
        tauler[f][c] = ch;
    }

    public char get(Point p) {
        return get(p.y, p.x);
    }

    public char get(int f, int c) {
        return tauler[f][c];
    }

    public boolean estaLliure(Point p) {
        return estaLliure(p.y, p.x);
    }

    public boolean estaLliure(int f, int c) {
        return get(f, c) == ' ';
    }

    public boolean hiHaPoma(Point p) {
        return get(p) == 'P';
    }

}
