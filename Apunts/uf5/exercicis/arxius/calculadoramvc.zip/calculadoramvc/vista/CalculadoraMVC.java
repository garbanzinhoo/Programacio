package uf5.exercicis.calculadoramvc.vista;

import uf5.exercicis.calculadoramvc.control.BotoListener;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;

/**
 * Classe per crear la finestra principal del programa.
 */
public class CalculadoraMVC extends JFrame {
    private final JTextField num1;  // Camp de text per introduir el primer número
    private final JLabel operacio;  // Espai per mostrar la operació
    private final JTextField num2;  // Camp de text per introduir el segon número
    private final JLabel resultat;  // Espai per mostrar el resultat

    /**
     * Constructor de la finestra principal del programa.
     */
    public CalculadoraMVC() {
        // Panell de la finestra principal
        Container panell = getContentPane();

        // Panell superior (n1, operació, n2)
        JPanel nums = new JPanel();
        nums.setLayout(new FlowLayout(FlowLayout.CENTER));
            num1 = new JTextField();
            num1.setPreferredSize(new Dimension(100, 30));
            num1.setHorizontalAlignment(SwingConstants.RIGHT);

            operacio = new JLabel();
            operacio.setPreferredSize(new Dimension(40, 29));
            operacio.setHorizontalAlignment(SwingConstants.CENTER);
            operacio.setBorder(BorderFactory.createLineBorder(Color.black, 1));

            num2 = new JTextField();
            num2.setPreferredSize(new Dimension(100, 30));
            num2.setHorizontalAlignment(SwingConstants.RIGHT);
        nums.add(num1);
        nums.add(operacio);
        nums.add(num2);

        // Panell central (resultat)
        JPanel res = new JPanel();
            resultat = new JLabel();
            resultat.setPreferredSize(new Dimension(250, 30));
            resultat.setHorizontalAlignment(SwingConstants.CENTER);
            resultat.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        res.add(resultat);

        // Panell inferior (botons)
        JPanel botons = new JPanel();
        // Organitzar com una graella de 1 fila x 4 columnes
        GridLayout gLayout = new GridLayout(1, 4);
        gLayout.setHgap(5); // Separació horitzontal entre botons
        botons.setLayout(gLayout);
        botons.setBorder(new EmptyBorder(6, 4, 6, 4));
        botons.setPreferredSize(new Dimension(250, 40));
            // Crear listener pels botons
            BotoListener bl = new BotoListener(this);
            // Crear botons +, -, *, / i assignar listener
            JButton sumar = new JButton("+");
            sumar.addActionListener(bl);
            JButton restar = new JButton("-");
            restar.addActionListener(bl);
            JButton multiplicar = new JButton("*");
            multiplicar.addActionListener(bl);
            JButton dividir = new JButton("/");
            dividir.addActionListener(bl);
        // Afegir botons al panell
        botons.add(sumar);
        botons.add(restar);
        botons.add(multiplicar);
        botons.add(dividir);

        // Afegir els diferents panells al panell de la finestra principal
        panell.add(nums, BorderLayout.PAGE_START);
        panell.add(res, BorderLayout.CENTER);
        panell.add(botons, BorderLayout.PAGE_END);

        // Configurar i mostar la finestra principal
        pack();                     // Reduir al màxim la finetra
        setResizable(false);        // Impedir que es pugui redimensionar
        setLocationRelativeTo(null);// Centra en pantalla
        setVisible(true);           // Mostra la finestra

        // Tanca el programa al tancar la finestra
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Retorna el contingut del camp de text num1.
     * @return Text
     */
    public String getNum1() {
        return num1.getText();
    }

    /**
     * Retorna el contingut del camp de text num2.
     * @return Text
     */
    public String getNum2() {
        return num2.getText();
    }

    /**
     * Actualitza (mostra) el camp operacio.
     * @param o Text que s'ha de mostrar
     */
    public void showOperacio(String o) {
        operacio.setText(o);
    }

    /**
     * Actualitza (mostra) el camp resultat.
     * @param r Text que s'ha de mostrar
     */
    public void showResultat(String r) {
        resultat.setText(r);
    }

    /**
     * Mètode que posa en marxa el programa
     * @param args No s'utilitzen
     */
    public static void main(String[] args) {
        new CalculadoraMVC();
    }
}
