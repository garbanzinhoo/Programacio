package uf5.exercicis.cucamvc.control;

import uf5.exercicis.cucamvc.model.Dades;
import uf5.exercicis.cucamvc.vista.Camp;

import javax.swing.*;
import java.time.Duration;
import java.time.Instant;

/**
 * Classe per administrador el joc (Controlador)
 */
public class Joc {
    // Constants
    private static final int RETARD = 200;
    private static final int TEMPS = 120;

    /**
     * Bucle fins que no es vulgui fer més partides
     * @param c Objecte Vista
     */
    public static void jugar(Camp c) {
        JFrame f = (JFrame) SwingUtilities.getWindowAncestor(c);
        int repetir;

        UIManager.put("OptionPane.yesButtonText", "Sí");
        UIManager.put("OptionPane.noButtonText", "No");

        do {
            partida(c);
            repetir = JOptionPane.showConfirmDialog(f, "Vols tornar a jugar?", "Jugar", JOptionPane.YES_NO_OPTION);
        } while (repetir == 0);

        System.exit(0);
    }

    /**
     * Bucle fins que s'acabi la partida
     * @param c Objecte Vista
     */
    public static void partida(Camp c) {
        Instant start = Instant.now();

        // Inicialitzar, redibuixar i esperar 1,5 segons per començar
        Dades.inicialitzar();
        Dades.dibuixar(c, TEMPS);
        try { Thread.sleep(1500); } catch (Exception e) { }

        // Repetir fins que s'acabi el temps o mori el cuc
        do {
            Dades.moure();
            Dades.dibuixar(c, TEMPS - (int)(Duration.between(start, Instant.now()).toMillis() / 1000));
            try { Thread.sleep(RETARD); } catch (Exception e) { }
        } while (!Dades.isFi() && (int)(Duration.between(start, Instant.now()).toMillis() / 1000) < TEMPS);
        Dades.dibuixar(c, 0);
    }
}
