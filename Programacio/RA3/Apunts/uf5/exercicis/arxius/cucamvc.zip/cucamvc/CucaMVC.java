package uf5.exercicis.cucamvc;

import uf5.exercicis.cucamvc.control.Joc;
import uf5.exercicis.cucamvc.vista.Camp;

public class CucaMVC {

    /**
     * Engega el joc
     * @param args Arguments per defecte (no s'utilitzen)
     */
    public static void main(String[] args) {
        try {
            Camp g = new Camp();
            Joc.jugar(g);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
