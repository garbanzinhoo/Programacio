package uf5.exemples.apunts.grafics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class DibuixUsuari extends JPanel {
    static final int P_WIDTH = 600;
    static final int P_HEIGHT = 400;
    static final int COSTAT = 100;

    ArrayList<Point> punts = new ArrayList<>();

    public DibuixUsuari() {
        setPreferredSize(new Dimension(P_WIDTH, P_HEIGHT));
        setBackground(Color.white);
        addMouseListener(
            new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    punts.add(e.getPoint());
                    repaint();
                }
            }
        );
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);        // Crida el mètode del pare per si ha de dibuixar
        Graphics2D g2 = (Graphics2D) g; // Converteix a Graphics2D per tenir més funcions

        g2.setStroke(new BasicStroke(4));
        g2.setColor(Color.blue);
        for (Point p : punts) g2.drawRect(p.x,p.y,COSTAT,COSTAT);
    }

    public static void main(String[] args) {
        JFrame f = new JFrame("DibuixUsuari");
        f.getContentPane().add(new DibuixUsuari());
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        f.pack();
        f.setVisible(true);
    }
}
