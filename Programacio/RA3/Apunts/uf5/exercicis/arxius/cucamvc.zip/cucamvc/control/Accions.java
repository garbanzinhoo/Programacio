package uf5.exercicis.cucamvc.control;

import uf5.exercicis.cucamvc.model.Dades;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Classe per gestionar el teclat (Controlador)
 */
public class Accions extends KeyAdapter {

    /**
     * Acció quan es prem una tecla
     * @param e Dades sobre l'esdeveniment
     */
    public void keyPressed(KeyEvent e) {
        // Obtenir el codi de la tecla premuda
        int fletxa = e.getKeyCode();

        if (fletxa == KeyEvent.VK_UP) Dades.setDir('N');
        else if (fletxa == KeyEvent.VK_DOWN) Dades.setDir('S');
        else if (fletxa == KeyEvent.VK_LEFT) Dades.setDir('E');
        else if (fletxa == KeyEvent.VK_RIGHT) Dades.setDir('O');
    }
}
