package uf5.exemples.apunts.grafics;

import java.util.*;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;

// Canvas amb doble buffer
public class CanvasDB extends Canvas {
    // Constants
    static final int MIDA = 48;
    static final int FILES = 9;
    static final int COLUMNES = 12;

    // Directori per les imatges i sons
    static final String RES = "uf5/exemples/apunts/grafics/resources/";

    // Posició de la mosca
    Point pMosca;

    // Imatge de la mosca
    Image iMosca;

    // So quan es mata la mosca
    Clip sMosca;

    // Per accelerar l'intercanvi de pàgines i evitar parpalleig
    BufferStrategy strategy;

    /**
     * Constructor de la finestra del joc.<br>
     * Configura la mida i el color de fons.
     */
    public CanvasDB() {
        setSize(new Dimension(COLUMNES * MIDA, FILES * MIDA));
        setBackground(Color.white);
    }

    /**
     * Crea un doble buffer per millorar l'eficiència en jocs amb animacions.
     */
    public void crearDobleBuffer() {
        setIgnoreRepaint(true);
        createBufferStrategy(2);
        strategy = getBufferStrategy();
    }

    /**
     * Redibuixa tota la zona de joc i la mostra.
     */
    public void dibuixar() {
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        super.paint(g);     // Esborra el fons

        g.drawImage(iMosca, pMosca.x * MIDA, pMosca.y * MIDA, null);

        g.dispose();
        strategy.show();
    }

    public void moure() {
        java.util.Timer timer = new java.util.Timer();
        timer.scheduleAtFixedRate(new TimerTask(){
            @Override
            public void run(){
                int f = (int) (Math.random() * (FILES));
                int c = (int) (Math.random() * (COLUMNES));
                pMosca = new Point(c, f);
                dibuixar();
                if (sMosca != null && f % 2 == 0 && c % 2 == 0) {
                    sMosca.setFramePosition(0);
                    sMosca.start();
                }
            }
        },0,700);

        /*
        while (true) {
            int f = (int) (Math.random() * (FILES));
            int c = (int) (Math.random() * (COLUMNES));
            pMosca = new Point(c, f);
            dibuixar();

            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        */
    }

    public boolean carregarImatges() {
        MediaTracker tracker = new MediaTracker(new Container());

        iMosca = LlibreriaGrafica.carregarImatge(RES + "mosca48.png", MIDA, MIDA);
        if (iMosca == null) return false;
        else tracker.addImage(iMosca, 0);

        try {
            tracker.waitForAll();
        } catch (InterruptedException e) {
            return false;
        }

        sMosca = LlibreriaGrafica.carregarSo(RES + "mosca.wav");
        return true;
    }

    public static void main(String[] args) {
        CanvasDB db = new CanvasDB();
        if (!db.carregarImatges()) {
            System.err.println("ERROR: no s'han pogut carregar les imatges");
            return;
        }

        JFrame f = new JFrame("DobleBuffer");
        f.getContentPane().add(db);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        f.pack();
        f.setVisible(true);

        db.crearDobleBuffer();
        db.moure();
    }
}
