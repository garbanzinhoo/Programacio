package uf5.exercicis.cucamvc.model;

import java.awt.*;
import java.util.LinkedList;

public class Cuc {
    final LinkedList<Point> cua;
    char dir;

    /**
     * Constructor del cuc.
     * @param fila Fila on es troba el cap
     * @param columna Columna on es troba el cap
     * @param dir Direcció cap a on s'ha de moure el cap
     */
    public Cuc(int fila, int columna, char dir) {
        cua = new LinkedList<>();
        this.dir = dir;

        int incF = 0;
        int incC = 0;

        switch (dir) {
            case 'N' -> --incF;
            case 'S' -> ++incF;
            case 'E' -> --incC;
            case 'O' -> ++incC;
        }

        afegirCua(fila - 2 * incF, columna - 2 * incC);
        afegirCua(fila - incF, columna - incC);
        afegirCua(fila, columna);
    }

    /**
     * Obtenir la següent posició en funció de la direcció.
     * @return La següent posició
     */
    public Point getNext() {
        Point p = cua.peekLast();
        int f = p.y;
        int c = p.x;

        switch (dir) {
            case 'N' -> --f;
            case 'S' -> ++f;
            case 'E' -> --c;
            case 'O' -> ++c;
        }

        return new Point(c, f);
    }

    public LinkedList<Point> getCua() {
        return cua;
    }

    public int getSize() {
        return cua.size();
    }

    public char getDir() {
        return dir;
    }

    public void setDir(char dir) {
        this.dir = dir;
    }

    /**
     * Avança la posició del cuc i elimina l'últim segment.<br>
     * Si menja la poma, no elimina l'últim segment i crea una nova poma.<br>
     * Si no pot avançar, només elimina l'últim segment.
     */
    public Point moure(boolean afegir, boolean treure) {
        Point p = getNext();

        if (afegir) afegirCua(p);
        if (treure) return treureCua();
        return null;
    }

    /**
     * Afegeix un segment al principi del cuc (cap).
     * @param f Fila dins del tauler
     * @param c Columna dins del tauler
     */
    public void afegirCua(int f, int c) {
        afegirCua(new Point(c, f));
    }

    /**
     * Afegeix un segment al principi del cuc (cap).
     * @param p Posició del segment
     */
    public void afegirCua(Point p) {
        cua.add(p);
    }

    /**
     * Elimina l'últim segment de la cua.
     * @return La posició del segment que s'ha eliminat
     */
    public Point treureCua() {
        if (cua.size() == 0) return null;

        return cua.remove();
    }
}
