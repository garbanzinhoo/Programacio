package uf5.exercicis.calculadoramvc.model;

/**
 * Classe per realitzar les operacions.
 */
public class Calcul {

    /**
     * Realitza una operació segons els paràmetres que se li passin.
     * @param num1 Text amb la primera dada
     * @param num2 Text amb la segona dada
     * @param operacio Text amb la operació
     * @return Valor real amb el resulat de la operació
     * @throws IllegalArgumentException Si algun dels paràmetres és incorrecte
     */
    static public float calcular(String num1, String num2, String operacio) throws IllegalArgumentException {
        // Convertir els valors
        float v1;   // Primer valor
        float v2;   // Segon valor

        try {
            v1 = Float.parseFloat(num1);
            v2 = Float.parseFloat(num2);
        } catch (NumberFormatException nfe) {
            throw new IllegalArgumentException("Valors incorrectes");
        }

        // Calcular
        float resultat;    // Resultat

        switch (operacio) {
            case "+":
                resultat = v1 + v2;
                break;
            case "-":
                resultat = v1 - v2;
                break;
            case "*":
                resultat = v1 * v2;
                break;
            case "/":
                resultat = v1 / v2;
                break;
            default:
                throw new IllegalArgumentException("Operació incorrecta");
        }

        return resultat;
    }
}
