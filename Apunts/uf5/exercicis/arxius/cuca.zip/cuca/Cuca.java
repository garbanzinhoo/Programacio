package cuca;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.util.LinkedList;

public class Cuca extends Canvas {
    // Constants
    private final int MIDA = 20;
    private final int FILES = 30;
    private final int COLUMNES = 40;
    private final int RETARD = 200;

    // Directori per les imatges
    private final String RES = "cuca/resources/";

    // Per accelerar l'intercanvi de pàgines i evitar parpalleig
    private final BufferStrategy strategy;

    // Indica si s'ha acabat el joc
    private boolean fi;

    // Imatge de la poma
    private final Image iPoma = carregarImatge(RES + "poma.png", MIDA);

    // Direcció del moviment: N (nort/amunt), S (sud/avall), E (est/esquerra), O (oest/dreta)
    private char dir;

    // Posició de la poma (poma.y = fila; poma.x = columna)
    private Point poma;

    // Llista amb la posició de cada segment del cuc
    private final LinkedList<Point> cua = new LinkedList<>();

    // Tauler: # (vores), P (poma), 0 (cuc)
    private final char[][] tauler = new char[FILES][COLUMNES];

    /**
     * Constructor de la zona de joc.
     */
    public Cuca() {
        // Crear finestra
        JFrame finestra = new JFrame("Cuca");

        // Configurar mides zona de joc (this) i afegir-la a la finestra
        JPanel panel = (JPanel)finestra.getContentPane();
        panel.setPreferredSize(new Dimension(COLUMNES * MIDA,FILES * MIDA));
        panel.setLayout(null);
        panel.add(this);
        setBounds(0,0,COLUMNES * MIDA,FILES * MIDA);
        setIgnoreRepaint(true);

        // Mostrar finestra
        finestra.pack();
        finestra.setResizable(false);
        finestra.setVisible(true);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Afegir un gestor d'esdeveniments per les tecles
        addKeyListener(new KeyInputHandler());
        requestFocus();

        // Crear doble buffer
        createBufferStrategy(2);
        strategy = getBufferStrategy();
    }

    /**
     * Inicialitza el joc.
     */
    private void inicialitzar() {
        fi = false;
        dir = 'E';

        // Buidar tauler marcant els límits amb #
        for (int i = 0; i < FILES; ++i) {
            for (int j = 0; j < COLUMNES; ++j) {
                if (i == 0 || i == FILES - 1 || j == 0 || j == COLUMNES - 1) {
                    tauler[i][j] = '#';
                } else {
                    tauler[i][j] = ' ';
                }
            }
        }

        // Afegir 3 segments al cuc
        int f = FILES / 2;
        int c = COLUMNES - COLUMNES / 4;

        afegirCua(f, c);
        afegirCua(f, c - 1);
        afegirCua(f, c - 2);

        // Crear la primera poma
        crearPoma();
    }

    /**
     * Afegeix un segment al principi del cuc (cap).
     * @param f Fila dins del tauler
     * @param c Columna dins del tauler
     */
    private void afegirCua(int f, int c) {
        cua.add(new Point(c, f));
        tauler[f][c] = '0';
    }

    /**
     * Elimina l'últim segment de la cua.
     */
    private void treureCua() {
        Point p = cua.remove();
        tauler[p.y][p.x] = ' ';
    }

    /**
     * Crea una poma en un lloc buit del tauler
     */
    private void crearPoma() {
        int f, c;

        do {
            f = (int)(Math.random() * (FILES - 2)) + 1;
            c = (int)(Math.random() * (COLUMNES - 2)) + 1;
        } while (tauler[f][c] != ' ');

        poma = new Point(c, f);
        tauler[f][c] = 'P';
    }

    /**
     * Redibuixa tota la zona de joc
     */
    private void dibuixar() {
        Point p = null;
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Esborrar el fons deixant les vores de color blau
        g.setColor(Color.blue);
        g.fillRect(0,0,COLUMNES * MIDA,FILES * MIDA);
        g.setColor(Color.black);
        g.fillRect(MIDA,MIDA,(COLUMNES - 2) * MIDA,(FILES - 2) * MIDA);

        // Color pel reflex
        Color c = new Color(1f, 1f, 1f, 0.6f);

        // Dibuixar cuca
        for (Point point : cua) {
            // Posició
            p = point;
            // Segment
            g.setColor(Color.green);
            g.fillOval(p.x * MIDA, p.y * MIDA, MIDA, MIDA);
            // Reflex
            g.setColor(c);
            g.fillOval(p.x * MIDA + MIDA / 5, p.y * MIDA + MIDA / 5, MIDA / 3, MIDA / 3);
        }

        // Dibuixar ulls al cap
        Point ull = new Point(p.x * MIDA, p.y * MIDA);
        Point inc = new Point(0, 0);
        int midaUll = MIDA / 5;

        switch (dir) {
            case 'N':
                ull.x += MIDA / 4;
                ull.y += MIDA / 4;
                inc.x = MIDA / 4 + 1;
                break;
            case 'S':
                ull.x += MIDA / 4;
                ull.y += MIDA / 2;
                inc.x = MIDA / 4 + 1;
                break;
            case 'E':
                ull.x += MIDA / 4;
                ull.y += MIDA / 4;
                inc.y = MIDA / 4 + 1;
                break;
            case 'O':
                ull.x += MIDA / 2;
                ull.y += MIDA / 4;
                inc.y = MIDA / 4 + 1;
                break;
        }
        g.setColor(Color.black);
        g.fillOval(ull.x, ull.y, midaUll, midaUll);
        g.fillOval(ull.x + inc.x, ull.y + inc.y, midaUll, midaUll);

        // Dibuixar poma
        g.drawImage(iPoma, poma.x * MIDA, poma.y * MIDA, null);

        // Actualitzar finestra
        g.dispose();
        strategy.show();
    }

    /**
     * Avança la posició del cuc i elimina l'últim segment.<br>
     * Si menja la poma, no elimina l'últim segment i crea una nova poma.<br>
     * Si no pot avançar, només elimina l'últim segment.
     */
    private void moure() {
        Point p = cua.peekLast();
        int f = p.y;
        int c = p.x;

        switch (dir) {
            case 'N' -> --f;
            case 'S' -> ++f;
            case 'E' -> --c;
            case 'O' -> ++c;
        }

        if (tauler[f][c] == 'P') {
            crearPoma();
            afegirCua(f, c);
        } else if (tauler[f][c] == ' ') {
            afegirCua(f, c);
            treureCua();
        } else {
            treureCua();
            if (cua.size() < 3) {
                fi = true;
            }
        }
    }

    /**
     * Bucle fins que s'acabi el joc
     */
    public void jugar() {
        while (!fi) {
            moure();
            dibuixar();
            try { Thread.sleep(RETARD); } catch (Exception e) { }
        }
    }

    /**
     * Carrega una imatge (poma) i la redimensiona.
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobat
     */
    private Image carregarImatge(String path, int mida) {
        Image imatge = carregarImatge(path);
        if (imatge == null) return null;

        imatge = imatge.getScaledInstance(mida, mida,  java.awt.Image.SCALE_SMOOTH);
        return imatge;
    }

    /**
     * Carrega una imatge (poma).
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobat
     */
    private Image carregarImatge(String path) {
        java.net.URL imgURL = ClassLoader.getSystemResource(path);
        if (imgURL != null) {
            ImageIcon icona =  new ImageIcon(imgURL);
            return icona.getImage();
        } else {
            System.err.println("No s'ha trobat l'arxiu: " + path);
            return null;
        }
    }

    /**
     * Classe per gestionar el teclat
     */
    private class KeyInputHandler extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            int tecla = e.getKeyCode();

            if (tecla == KeyEvent.VK_UP) dir = 'N';
            if (tecla == KeyEvent.VK_DOWN) dir = 'S';
            if (tecla == KeyEvent.VK_LEFT) dir = 'E';
            if (tecla == KeyEvent.VK_RIGHT) dir = 'O';
        }
    }

    /**
     * Engega el joc
     * @param args Arguments per defecte (no s'utilitzen)
     */
    public static void main(String[] args) {
        Cuca g = new Cuca();

        g.inicialitzar();
        g.jugar();
    }
}
