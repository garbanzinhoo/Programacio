package uf5.exercicis.cucamvc.vista;

import uf5.exercicis.cucamvc.control.Accions;
import uf5.exercicis.cucamvc.model.Cuc;
import uf5.exercicis.cucamvc.model.Poma;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.util.LinkedList;

/**
 * Objecte de tipus Canvas per dibuixar el joc (Vista)
 */
public class Camp extends Canvas {
    // Constants
    private final int MIDA = 24;
    private final int FILES = 30;
    private final int COLUMNES = 40;

    // Directori per les imatges
    private final String RES = "uf5/exercicis/cucamvc/resources/";

    // Per accelerar l'intercanvi de pàgines i evitar parpalleig
    private final BufferStrategy strategy;

    // Imatge de la poma
    private final Image iPoma = carregarImatge(RES + "poma.png", MIDA);
    // Imatge dels ulls per les 4 direccions
    private final Image iUllsN = carregarImatge(RES + "ullsN.png", MIDA);
    private final Image iUllsS = carregarImatge(RES + "ullsS.png", MIDA);
    private final Image iUllsE = carregarImatge(RES + "ullsE.png", MIDA);
    private final Image iUllsO = carregarImatge(RES + "ullsO.png", MIDA);

    /**
     * Constructor de la finestra del joc.
     */
    public Camp() throws Exception {
        if (iPoma == null) throw new Exception("No s'ha trobat la imatge de la poma");

        // Crear finestra
        JFrame finestra = new JFrame("Cuca");

        // Configurar mides de la zona de joc (this) i afegir-la a la finestra
        JPanel panel = (JPanel) finestra.getContentPane();
        panel.setPreferredSize(new Dimension(COLUMNES * MIDA, FILES * MIDA));
        panel.setLayout(null);
        panel.add(this);
        setBounds(0, 0, COLUMNES * MIDA, FILES * MIDA);
        setBackground(Color.black);

        // Mostrar finestra
        finestra.pack();
        finestra.setResizable(false);
        finestra.setVisible(true);
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Afegir un gestor d'esdeveniments per les tecles
        addKeyListener(new Accions());
        requestFocus();

        // Crear doble buffer i configurar
        createBufferStrategy(2);
        strategy = getBufferStrategy();
        setIgnoreRepaint(true);

        // Força la càrrega de les imatges
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        g.drawImage(iPoma, 0, 0, null);
        g.drawImage(iUllsN, 0, 0, null);
        g.drawImage(iUllsS, 0, 0, null);
        g.drawImage(iUllsE, 0, 0, null);
        g.drawImage(iUllsO, 0, 0, null);
    }

    /**
     * Redibuixa tota la zona de joc.
     * @param cuc Dades del cuc (posició de cada segment de la cua)
     * @param poma Dades de la poma (posició)
     * @param segons temps restant per finalitzar el joc
     */
    public void dibuixar(Cuc cuc, Poma poma, int segons) {
        Graphics2D g = (Graphics2D) strategy.getDrawGraphics();
        dibuixarCamp(g);

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        dibuixarCuc(cuc, g);
        g.drawImage(iPoma, poma.getColumna() * MIDA, poma.getFila() * MIDA, null);

        g.setColor(Color.white);
        g.setFont(new Font("", Font.PLAIN, (int) (MIDA * .8f)));
        g.drawString(cuc.getSize() + " punts", MIDA, (int) (MIDA * .8f));
        g.drawString(String.format("%6s s", segons), MIDA * (COLUMNES - 4), (int) (MIDA * .8f));

        g.dispose();
        strategy.show();
    }

    /**
     * Esborrar el fons deixant les vores de color blau.
     * @param g Context gràfic per dibuixar
     */
    private void dibuixarCamp(Graphics g) {
        g.setColor(Color.blue);
        g.fillRect(0, 0, COLUMNES * MIDA, FILES * MIDA);
        g.setColor(Color.black);
        g.fillRect(MIDA, MIDA, (COLUMNES - 2) * MIDA, (FILES - 2) * MIDA);
    }

    /**
     * Dibuixar el cuc.
     * @param cuc Cuc
     * @param g Context gràfic per dibuixar
     */
    private void dibuixarCuc(Cuc cuc, Graphics2D g) {
        Point p = null;

        // Color pel reflex
        Color c = new Color(1f, 1f, 1f, 0.6f);
        LinkedList<Point> cua = cuc.getCua();

        // Dibuixar cuca
        for (Point point : cua) {
            // Posició
            p = point;
            // Segment
            g.setColor(Color.green);
            g.fillOval(p.x * MIDA, p.y * MIDA, MIDA, MIDA);
            // Reflex
            g.setColor(c);
            g.fillOval(p.x * MIDA + MIDA / 5, p.y * MIDA + MIDA / 5, MIDA / 3, MIDA / 3);
        }

        // Dibuixar cap amb ulls
        g.setColor(Color.green);
        g.fillOval(p.x * MIDA, p.y * MIDA, MIDA, MIDA);
        switch (cuc.getDir()) {
            case 'N':
                g.drawImage(iUllsN, p.x * MIDA, p.y * MIDA, null);
                break;
            case 'S':
                g.drawImage(iUllsS, p.x * MIDA, p.y * MIDA, null);
                break;
            case 'E':
                g.drawImage(iUllsE, p.x * MIDA, p.y * MIDA, null);
                break;
            case 'O':
                g.drawImage(iUllsO, p.x * MIDA, p.y * MIDA, null);
                break;
        }
    }

    /**
     * Carrega una imatge i la redimensiona.
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobat
     */
    private Image carregarImatge(String path, int mida) {
        Image imatge = carregarImatge(path);
        if (imatge == null) return null;

        imatge = imatge.getScaledInstance(mida, mida,  Image.SCALE_SMOOTH);
        return imatge;
    }

    /**
     * Carrega una imatge .
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobat
     */
    private Image carregarImatge(String path) {
        java.net.URL imgURL = ClassLoader.getSystemResource(path);
        if (imgURL != null) {
            ImageIcon icona =  new ImageIcon(imgURL);
            return icona.getImage();
        } else {
            System.err.println("No s'ha trobat l'arxiu: " + path);
            return null;
        }
    }
}
