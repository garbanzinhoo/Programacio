package uf5.exemples.apunts.grafics;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class LlibreriaGrafica {
    /**
     * Carrega una icona i la redimensiona.
     * @param path Ruta on es troba la imatge
     * @return La icona creada o null si no l'ha trobada
     */
    public static ImageIcon carregarIcona(String path, int width, int height) {
        Image imatge = carregarImatge(path);
        if (imatge == null) return null;

        imatge = imatge.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(imatge);
    }

    /**
     * Carrega una imatge i la redimensiona.
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobada
     */
    public static Image carregarImatge(String path, int width, int height) {
        Image imatge = carregarImatge(path);
        if (imatge == null) return null;

        imatge = imatge.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return imatge;
    }

    /**
     * Carrega una imatge.
     * @param path Ruta on es troba la imatge
     * @return La imatge creada o null si no l'ha trobada
     */
    public static Image carregarImatge(String path) {
        java.net.URL imgURL = ClassLoader.getSystemResource(path);
        if (imgURL != null) {
            ImageIcon icona = new ImageIcon(imgURL);
            return icona.getImage();
        } else {
            System.err.println("No s'ha trobat l'arxiu: " + path);
            return null;
        }
    }

    /**
     * Carrega un so.
     * @param path Ruta on es troba el so
     * @return El so carregat o null si no l'ha trobat
     */
    public static Clip carregarSo(String path) {
        Clip so;

        try {
            java.net.URL soundURL = ClassLoader.getSystemResource(path);
            if (soundURL == null) return null;

            Line.Info linfo = new Line.Info(Clip.class);
            Line line = AudioSystem.getLine(linfo);
            so = (Clip) line;
            AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL);
            so.open(ais);
            return so;
        } catch (LineUnavailableException lue) {
            System.err.println("No s'ha trobat l'arxiu: " + path);
            return null;
        } catch (UnsupportedAudioFileException uafe) {
            System.err.println("Format d'àudio no soportat: " + path);
            return null;
        } catch (IOException ioe) {
            System.err.println("Error d'entrada/sortida: " + path);
            return null;
        }
    }
}
