package uf5.exercicis.cucamvc.model;

import uf5.exercicis.cucamvc.vista.Camp;

import java.awt.*;
import javax.sound.sampled.*;
import java.io.IOException;

/**
 * Classe per gestionar les dades del joc (Model)
 */
public class Dades {
    // Constants
    private static final int FILES = 30;
    private static final int COLUMNES = 40;

    // Directori pels sons
    private static final String RES = "uf5/exercicis/cucamvc/resources/";

    private static final Clip sMenjar = carregarSo(RES + "menjar.wav");
    private static final Clip sMort = carregarSo(RES + "mort.wav");

    // Indica si s'ha acabat el joc
    private static boolean fi;

    // Posició de la poma (poma.y = fila; poma.x = columna)
    private static Poma poma;

    // Cuc
    private static Cuc cuc;

    // Tauler: # (vores), P (poma), 0 (cuc)
    private static final Tauler tauler = new Tauler(FILES, COLUMNES);

    /**
     * Crea una poma en un lloc buit del tauler
     */
    private static void crearPoma() {
        int f, c;

        do {
            f = (int)(Math.random() * (FILES - 2)) + 1;
            c = (int)(Math.random() * (COLUMNES - 2)) + 1;
        } while (!tauler.estaLliure(f, c));

        poma = new Poma(f, c);
        tauler.set(f, c, 'P');
    }

    /**
     * Carrega un so (menjar).
     * @param path Ruta on es troba el so
     * @return El so carregat o null si no l'ha trobat
     */
    private static Clip carregarSo(String path) {
        Clip c;

        try {
            java.net.URL soundURL = ClassLoader.getSystemResource(path);
            if (soundURL == null) return null;

            Line.Info linfo = new Line.Info(Clip.class);
            Line line = AudioSystem.getLine(linfo);
            c = (Clip) line;
            AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL);
            c.open(ais);
            return c;
        } catch (LineUnavailableException lue) {
            System.err.println("No s'ha trobat l'arxiu: " + path);
            return null;
        } catch (UnsupportedAudioFileException uafe) {
            System.err.println("Format d'àudio no soportat: " + path);
            return null;
        } catch (IOException ioe) {
            System.err.println("Error d'entrada/sortida: " + path);
            return null;
        }
    }

    /**
     * Inicialitza el joc.
     */
    public static void inicialitzar() {
        fi = false;

        tauler.inicialitzar();

        cuc = new Cuc(FILES / 2, COLUMNES - COLUMNES / 6 - 1, 'E');

        // Crear la primera poma
        crearPoma();
    }

    /**
     * Serveix per comprovar si s'ha acabat el joc.
     * @return <em>true</em> si s'ha acabat eel joc
     */
    public static boolean isFi() {
        return fi;
    }

    /**
     * Canviar la direcció del cuc.
     * @param dir Direcció del cuc ('N', 'S', 'E', 'O')
     */
    public static void setDir(char dir) {
        cuc.setDir(dir);
    }

    /**
     * Avança la posició del cuc i elimina l'últim segment.<br>
     * Si menja la poma, no elimina l'últim segment i crea una nova poma.<br>
     * Si no pot avançar, només elimina l'últim segment.
     */
    public static void moure() {
        Point p;

        p = cuc.getNext();

        if (tauler.hiHaPoma(p)) {
            // Menjar poma
            if (sMenjar != null) {
                sMenjar.setFramePosition(0);
                sMenjar.start();
            }
            crearPoma();
            tauler.set(p, '0');
            cuc.moure(true, false);
        } else if (tauler.estaLliure(p)) {
            // Avançar
            tauler.set(p, '0');
            p = cuc.moure(true, true);
            tauler.set(p, ' ');
        } else {
            // No pot avançar
            p = cuc.moure(false, true);
            tauler.set(p, ' ');
            if (cuc.getSize() < 3) {
                // Ha mort
                if (sMort != null) {
                    sMort.setFramePosition(0);
                    sMort.start();
                }
                fi = true;
            }
        }
    }

    /**
     * Redibuixa tot.
     * @param c Vista
     * @param temps Temps restant
     */
    public static void dibuixar(Camp c, int temps) {
        c.dibuixar(cuc, poma, temps);
    }
}
