package uf5.exercicis.calculadoramvc.control;

import uf5.exercicis.calculadoramvc.model.Calcul;
import uf5.exercicis.calculadoramvc.vista.CalculadoraMVC;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe per gestionar els esdeveniments sobre els botons.
 */
public class BotoListener implements ActionListener {
    /**
     * Objecte per poder passar dades a la vista.
     */
    private final CalculadoraMVC calculadora;

    /**
     * Constructor.
     * @param c Un objecte de tipus Calculadora (vista)
     */
    public BotoListener(CalculadoraMVC c) {
        calculadora = c;
    }

    /**
     * Acció a realitzar quan l'usuari prem un dels botons.
     * @param ev Conté tota la informació relacionada amb l'esdeveniment
     */
    @Override
    public void actionPerformed(ActionEvent ev) {
        // Agafar el text dels camps num1 i num2, i convertir a float
        String num1 = calculadora.getNum1();
        String num2 = calculadora.getNum2();
        String operacio = ev.getActionCommand();

        // Solicitar al model que faci el càlcul i retorni el resultat
        float r;

        try {
            r = Calcul.calcular(num1, num2, operacio);
        } catch (IllegalArgumentException ex) {
            calculadora.showOperacio("");
            calculadora.showResultat(ex.getMessage());
            return;
        }

        // Mostrar dades en la vista
        String resultat = "";

        // Per evitar que si el resultat és un enter surti XXX.0
        if (r == (int)r) resultat += ((int)r);
        else resultat += r;

        calculadora.showOperacio(operacio);
        calculadora.showResultat(resultat);
    }
}
