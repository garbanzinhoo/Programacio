package uf5.exemples.apunts.grafics;

import javax.swing.*;
import java.awt.*;

public class DibuixEstatic extends JPanel {
    static final int P_WIDTH = 600;
    static final int P_HEIGHT = 300;
    static final int WIDTH = 80;
    static final int HEIGHT = 60;
    static final int MIDA = 2 * WIDTH;

    // Directori per les imatges
    static final String RES = "uf5/exemples/apunts/grafics/resources/";

    // Imatge de Java
    Image iJava;

    @Override
    protected void paintComponent(Graphics g) {
        int x, y;

        super.paintComponent(g);        // Crida el mètode del pare per si ha de dibuixar
        Graphics2D g2 = (Graphics2D) g; // Converteix a Graphics2D per tenir més funcions

        // Activa antialiasing per suavitzar les línies
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Pinta tot el fons de blanc
        g2.setColor(Color.white);
        g2.fillRect(0,0,P_WIDTH,P_HEIGHT);

        x = 10;
        y = HEIGHT / 3;
        g2.setColor(Color.black);
        g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, HEIGHT/3));
        g2.drawString("Text amb tipus Sans Serif, negreta i mida " + (HEIGHT/3), x, y);

        g2.setStroke(new BasicStroke(4));
        g2.setColor(Color.red);
        y += HEIGHT / 3;
        g2.drawLine(x,y,x+WIDTH,y+HEIGHT);
        x += WIDTH + 20;
        g2.drawRect(x,y,WIDTH,HEIGHT);
        x += WIDTH + 20;
        g2.drawRoundRect(x,y,WIDTH,HEIGHT,WIDTH/2,HEIGHT/2);

        x = 10;
        y += HEIGHT + 20;
        g2.setColor(Color.green);
        g2.fillOval(x,y,WIDTH,HEIGHT);
        x += WIDTH + 20;
        g2.fillArc(x,y,WIDTH,HEIGHT,180,180);
        x += WIDTH + 20;
        g2.fillPolygon(new int[]{x,x+WIDTH,x+WIDTH/2}, new int[]{y+HEIGHT, y+HEIGHT, y},3);

        x += WIDTH + 50;
        y -= 2 * HEIGHT - 20;
        g2.drawImage(iJava, x, y, MIDA, MIDA, null);
    }

    public boolean carregarImatges() {
        MediaTracker tracker = new MediaTracker(new Container());

        iJava = LlibreriaGrafica.carregarImatge(RES + "java.png", MIDA, MIDA);
        if (iJava == null) return false;
        else tracker.addImage(iJava, 0);

        try {
            tracker.waitForAll();
            return true;
        } catch (InterruptedException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        DibuixEstatic panell = new DibuixEstatic();
        panell.setPreferredSize(new Dimension(P_WIDTH, P_HEIGHT));
        if (!panell.carregarImatges()) {
            System.err.println("ERROR: no s'han pogut carregar les imatges");
            return;
        }

        JFrame f = new JFrame("ExempleDibuix");
        f.getContentPane().add(panell);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        f.pack();
        f.setVisible(true);
    }
}